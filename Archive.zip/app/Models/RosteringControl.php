<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RosteringControl extends Model
{
    use HasFactory;
    protected $table = 'rostering_controls';
}
