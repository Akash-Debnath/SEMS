<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WeeklyLeave extends Model
{
    use HasFactory;
    protected $table = "weekly_leaves";
    // protected $fillable = [];
}
