<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Followup_meetingController extends Controller
{
    //
}
