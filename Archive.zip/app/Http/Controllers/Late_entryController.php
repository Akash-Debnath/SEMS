<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Late_entryController extends Controller
{
    //
}
