<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Facility_optionsController extends Controller
{
    //
}
