<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Ramadan_office_timeController extends Controller
{
    //
}
