<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PolicyFilesController extends Controller
{
    //
}
