<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Leave_attachmentController extends Controller
{
    //
}
