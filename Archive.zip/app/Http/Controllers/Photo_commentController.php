<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Photo_commentController extends Controller
{
    //
}
