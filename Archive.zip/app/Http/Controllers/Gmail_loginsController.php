<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Gmail_loginsController extends Controller
{
    //
}
