<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Missing_attendance_mail_sentController extends Controller
{
    //
}
