@extends('index')
@section('title', '| Ramadan')
@section('wrapper')
@parent

{{-- @author Akash Chandra Debnath
@Behaviour Set ramadan date and time, edit, update, delete --}}

@section('content-wrapper')
@parent
@section('content-header')

<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h4>Ramadan Time</h4>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#">Employee</a></li>
                    <li class="breadcrumb-item"><a href="#">HR & Admin</a></li>
                    <li class="breadcrumb-item active">Edit Ramadan Date</li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                @if ($errors->any())
                    <div class="w-100 alert alert-warning alert-dismissible fade show" id="failMsg" role="alert">
                        <strong>{{ implode('', $errors->all(':message')) }}</strong>
                        <button type="button" class="close" role="alert" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @elseif ($message = Session::get('success'))
                    <div class="w-100 alert alert-success alert-dismissible fade show" id="successMsg" role="alert">
                        <strong>{{ $message }}</strong>
                        <button type="button" class="close" role="alert" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @elseif ($message = Session::get('fail'))
                    <div class="w-100 alert alert-warning alert-dismissible fade show" id="failMsg" role="alert">
                        <strong> {{ $message }} </strong>
                        <button type="button" class="close" role="alert" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @endif
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
@endsection

@section('main-content')
@parent
@section('container-fluid')
@parent
<!--edit here-->
@section('row')
<div class="card">
    @if(Auth::user()->can('ramadan-create'))
        <div class="card-header d-flex justify-content-end">
            <button type="button" class="btn btn-info ml-auto  " data-toggle="modal" data-target="#modal-default">
                <span class=" fas fa-plus "> </span> Add Ramadan
            </button>
        </div>
    @endif
    <div class="card-body">
        <table class="table table-hover table-bordered  selectpicker" data-live-search="true">
            <thead>
                <tr>
                    <th>SL</th>
                    <th>From</th>
                    <th>To</th>
                    @if (Auth::user()->can('ramadan-create') || Auth::user()->can('ramadan-delete'))
                        <th class="text-center">Action</th>
                    @endif
                </tr>
            </thead>
            <tbody>
                @php  $i = $ramadanlist->currentPage()==1 ? 0 : ($ramadanlist->currentPage() -1 )*20  @endphp
                @foreach ($ramadanlist as $ramadans)
                <tr>
                    <td>{{ ++$i }}</td>
                    <td>{{ $ramadans->date_from }}  [{{ $ramadans->stime }}]</td>
                    <td>{{ $ramadans->date_to }}    [{{ $ramadans->etime }}]</td>
                    <td class="d-flex justify-content-center">
                       <!-- to edit -->
                       @if(Auth::user()->can('ramadan-create'))
                        <button type="button" class="btn btn-xs btn-info  " data-toggle="modal" data-target="#edit" onclick="getData({{ $ramadans->id }})">
                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                                    <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z" />
                                    <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z" />
                                </svg>
                            </button>
                        @endif
                        <!-- to delete -->
                        @if(Auth::user()->can('ramadan-delete'))
                            <form action="{{ route('ramadan.destroy', $ramadans->id ) }}" method="post" class="ml-1" >
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-xs" onclick="return confirm('Are you sure want to delete this ramadan schedule?')"> <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" class="bi bi-archive" viewBox="0 0 16 16">
                                    <path d="M0 2a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1v7.5a2.5 2.5 0 0 1-2.5 2.5h-9A2.5 2.5 0 0 1 1 12.5V5a1 1 0 0 1-1-1V2zm2 3v7.5A1.5 1.5 0 0 0 3.5 14h9a1.5 1.5 0 0 0 1.5-1.5V5H2zm13-3H1v2h14V2zM5 7.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5z"/>
                                </svg> </button> 
                            </form>
                        @endif
                    </div>
                </td>
                </tr>
                @endforeach
            </tbody>
        </table>

        <!-- modal -->
        @if(Auth::user()->can('ramadan-create'))
            <div class="modal fade" id="modal-default">
                <div class="modal-dialog  modal-dialog-centered ">
                    <div class="modal-content">
                        <div class="modal-header bg-info">
                            <h4 class="modal-title "> Add Ramadan</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="{{ route('ramadan.store') }}" method="POST" enctype="multipart/form-data">
                                @csrf
                        
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="date">From</label>
                                        <input type="date" placeholder="dd/mm/yyyy" id="date" name="date_from" class="form-control js-date-field bg-transparent" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="date">Start Time</label>
                                        <input type="time" placeholder="hh:mm:ss" id="date" name="stime" class="form-control js-time-field bg-transparent" required>
                                    </div>
                                </div>                         
                        
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="subject">To</label>
                                        <input type="date" placeholder="dd/mm/yyyy" id="" name="date_to" class="form-control js-date-field bg-transparent">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="subject">To</label>
                                        <input type="time" placeholder="hh:mm:ss" id="" name="etime" class="form-control js-time-field bg-transparent">
                                    </div>
                                </div>
                            
                                <div class="row d-flex justify-content-between">
                                    <div class="col-md-2 ">
                                        <button type="button" class="btn btn-danger btn-sm form-control" data-dismiss="modal">Close</button>
                                    
                                    </div>

                                    <div class="col-md-3 ">
                                        <button type="submit" class="btn btn-info btn-sm mt-2 mt-md-0 form-control" >Save Changes</button>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>
                    <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
            </div>
        @endif
        <!--////modal--finish  -->

        <!-- modal -->
        @if(Auth::user()->can('ramadan-edit'))
            <div class="modal fade  " id="edit">
                <div class="modal-dialog  modal-dialog-centered ">
                    <div class="modal-content">
                        <div class="modal-header bg-info">
                            <h4 class="modal-title "> Edit Ramadan</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="{{ url('update-ramadan') }}" method="POST">
                                @csrf
                                @method('PUT')
                            
                                <input type="hidden" id="ramadanId" name="ramadanId" />
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="date">From</label>
                                        <input type="date" placeholder="dd/mm/yyyy" id="dateFrom" name="date_from" class="form-control js-date-field bg-transparent" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="date">Start Time</label>
                                        <input type="time" placeholder="hh:mm:ss" id="startTime" name="stime" class="form-control js-time-field bg-transparent" required>
                                    </div>
                                </div>                         
                        
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="subject">To</label>
                                        <input type="date" placeholder="dd/mm/yyyy" id="dateTo" name="date_to" class="form-control js-date-field bg-transparent">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="subject">To</label>
                                        <input type="time" placeholder="hh:mm:ss" id="endTime" name="etime" class="form-control js-time-field bg-transparent">
                                    </div>
                                </div>
                            
                                <div class="row d-flex justify-content-between">
                                    <div class="col-md-2 ">
                                        <button type="button" class="btn btn-danger btn-sm form-control" data-dismiss="modal">Close</button>
                                    </div>

                                    <div class="col-md-3 ">
                                        <button type="submit" class="btn btn-info btn-sm mt-2 mt-md-0 form-control" >Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
            </div>
        @endif
        <!--////modal--finish  -->
    </div>
    <div class="card-footer overflow-auto ">
        {!! $ramadanlist->Links('pagination::bootstrap-4') !!}
    </div>
</div>
@endsection
<!-- end editing-->
@endsection
@endsection
@endsection


@section('script')
@parent

<script>
    function getData(id) {
        $('#ramadanId').val(id);
        $.ajax({
            type: "GET",
            url: "edit-ramadan/"+id,
            success: function(response){
                $('#dateFrom').val(response.ramadann.date_from);
                $('#startTime').val(response.ramadann.stime);
                $('#dateTo').val(response.ramadann.date_to);
                $('#endTime').val(response.ramadann.etime);
            },
            error: function (jqXhr, textStatus, errorMessage) { // error callback 
                console.log(errorMessage) ;
            }
        });
    }

    //Date and time field customiztion
    $(function(){
        $('.js-date-field').flatpickr();
        $('.js-time-field').flatpickr({
            enableTime: true,
            noCalendar: true,
            dateFormat: "H:i",
            time_24hr: false,
            defaultHour: 12
        });
    });

    setTimeout(function() {
    $('#successMsg').fadeOut('slow');
    $('#failMsg').fadeOut('slow');
    }, 3000);

</script>
@endsection
@endsection