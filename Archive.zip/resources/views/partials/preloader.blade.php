<!-- Preloader -->
<div class="preloader flex-column justify-content-center align-items-center">
  {{-- <img class="animation__shake" src="{{asset('dist/img/logo.svg')}}" alt="Genuity Logo" height="60" width="60"> --}}
  <img class="animation__shake" src="{{asset('dist/img/govt.png')}}" alt="Genuity Logo" height="60" width="60">
</div>
